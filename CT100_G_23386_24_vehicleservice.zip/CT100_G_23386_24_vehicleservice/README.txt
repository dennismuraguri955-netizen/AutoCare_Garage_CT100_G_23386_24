AUTOCARE GARAGE — VEHICLE SERVICE BOOKING AND COST ESTIMATION SYSTEM
Registration: CT100/G/23386/24

FILES
- index.html: home page and booking form
- service.html: service catalogue
- style.css: responsive styling
- script.js: validation, dynamic vehicle information, age warning and live estimate
- process_service.php: POST handling, server validation and independent total calculation

INDIVIDUAL REQUIREMENT
For registration number ending in 6: Computer Diagnosis is free whenever Full Service is selected.
This rule is implemented in both JavaScript and PHP.

RUNNING THE PROJECT
1. Install XAMPP.
2. Copy the entire project folder into C:\xampp\htdocs\
3. Start Apache from the XAMPP Control Panel.
4. Open http://localhost/CT100_G_23386_24_vehicleservice/index.html
5. Test the form and submit it. PHP will not run by opening the HTML file directly.

SCREENSHOTS TO TAKE YOURSELF
1. Home page and blank booking form.
2. Validation message after submitting incomplete details.
3. Vehicle type selected and the dynamic information displayed.
4. Multiple services selected and the live estimate visible.
5. Full Service + Computer Diagnosis selected; diagnosis should show FREE.
6. Successful PHP booking confirmation page after submission.
7. Optional: Our Services page.

Use real screenshots from your own running application for your practical demonstration. Do not submit mock screenshots as proof of execution.
