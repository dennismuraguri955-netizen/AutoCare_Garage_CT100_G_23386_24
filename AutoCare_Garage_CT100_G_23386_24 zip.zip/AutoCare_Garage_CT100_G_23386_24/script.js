// AutoCare Garage client-side validation and live cost calculator.
const form = document.getElementById('bookingForm');
const money = amount => 'KSh ' + amount.toLocaleString('en-KE');
const serviceNames = {oil:'Engine Oil Change', brake:'Brake Inspection', wheel:'Wheel Alignment', diagnosis:'Computer Diagnosis', full:'Full Service'};
const checks = () => [...document.querySelectorAll('input[name="services[]"]')];
const selectedServices = () => checks().filter(box => box.checked);
const yearInput = document.getElementById('year');
const vehicleType = document.getElementById('vehicle_type');
const serviceDate = document.getElementById('service_date');

// Set the earliest service date to today, using the browser's local date.
const today = new Date();
const localToday = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
serviceDate.min = localToday;
yearInput.max = today.getFullYear();

function calculateServiceCost() {
  const selected = selectedServices();
  const fullServiceSelected = selected.some(box => box.value === 'full');
  let total = 0;
  const items = [];
  selected.forEach(box => {
    let price = Number(box.dataset.price);
    if (box.value === 'diagnosis' && fullServiceSelected) price = 0;
    total += price;
    items.push({name:serviceNames[box.value], price});
  });
  document.getElementById('serviceCount').textContent = selected.length;
  document.getElementById('selectedInfo').textContent = `${selected.length} service${selected.length===1?'':'s'} selected.`;
  document.getElementById('totalCost').textContent = money(total);
  document.getElementById('diagnosisPrice').textContent = fullServiceSelected ? 'FREE with Full Service' : 'KSh 3,500';
  const discountInfo = document.getElementById('discountInfo');
  discountInfo.hidden = !(fullServiceSelected && selected.some(box => box.value === 'diagnosis'));
  const estimateItems = document.getElementById('estimateItems');
  estimateItems.innerHTML = '';
  if (!items.length) {
    estimateItems.innerHTML = '<p class="empty">Your selected services will appear here.</p>';
  } else {
    items.forEach(item => {
      const row = document.createElement('div');
      row.className = 'estimate-item';
      const name = document.createElement('span');
      const price = document.createElement('strong');
      name.textContent = item.name;
      price.textContent = item.price === 0 ? 'FREE' : money(item.price);
      row.append(name, price);
      estimateItems.appendChild(row);
    });
  }
}
function checkVehicleAge() {
  const year = Number(yearInput.value);
  const warning = document.getElementById('ageWarning');
  if (year && year >= 1950 && year <= new Date().getFullYear() && new Date().getFullYear()-year > 15) {
    warning.hidden = false;
    warning.textContent = `This vehicle is about ${new Date().getFullYear()-year} years old. Consider a careful inspection.`;
  } else {
    warning.hidden = true;
    warning.textContent = '';
  }
}
function updateVehicleInfo() {
  const info = document.getElementById('vehicleInfo');
  const messages = {
    'Saloon Car':'Saloon cars: routine maintenance helps with everyday driving.',
    'SUV':'SUVs: remember to check tyres, brakes and alignment regularly.',
    'Pickup':'Pickups: consider inspection frequency based on load and usage.',
    'Van':'Vans: regular checks can help keep work trips dependable.'
  };
  info.textContent = messages[vehicleType.value] || 'Choose a vehicle type to see useful information.';
}
function validateServiceForm() {
  const errors = [];
  const name = document.getElementById('customer_name').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const email = document.getElementById('email').value.trim();
  const registration = document.getElementById('registration').value.trim();
  const model = document.getElementById('vehicle_model').value.trim();
  const year = Number(yearInput.value);
  if (!name) errors.push('Please enter the customer name.');
  if (!/^\d{10}$/.test(phone)) errors.push('Phone number must contain exactly 10 digits.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) errors.push('Please enter a valid email address.');
  if (!registration) errors.push('Please enter the vehicle registration number.');
  if (!vehicleType.value) errors.push('Please select a vehicle type.');
  if (!model) errors.push('Please enter the vehicle model.');
  if (!year || year < 1950 || year > new Date().getFullYear()) errors.push('Enter a reasonable year of manufacture (1950 to current year).');
  if (!serviceDate.value || serviceDate.value < localToday) errors.push('Choose today or a future service date.');
  if (!selectedServices().length) errors.push('Select at least one service.');
  const message = document.getElementById('formMessage');
  if (errors.length) {
    message.hidden = false;
    message.innerHTML = '<strong>Please correct the following:</strong><ul>' + errors.map(e => `<li>${e}</li>`).join('') + '</ul>';
    message.scrollIntoView({behavior:'smooth',block:'center'});
    return false;
  }
  message.hidden = true;
  message.textContent = '';
  return true;
}
checks().forEach(box => box.addEventListener('change', calculateServiceCost));
yearInput.addEventListener('input', checkVehicleAge);
vehicleType.addEventListener('change', updateVehicleInfo);
document.getElementById('phone').addEventListener('input', event => {
  event.target.value = event.target.value.replace(/\D/g,'').slice(0,10);
});
form.addEventListener('submit', event => {
  if (!validateServiceForm()) event.preventDefault();
});
calculateServiceCost();
