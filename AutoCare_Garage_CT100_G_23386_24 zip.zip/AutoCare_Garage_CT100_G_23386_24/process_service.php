<?php
// AutoCare Garage: server-side validation and independent cost verification.
date_default_timezone_set('Africa/Nairobi');
$prices = [
    'oil' => 3000,
    'brake' => 2000,
    'wheel' => 2500,
    'diagnosis' => 3500,
    'full' => 8000
];
$names = [
    'oil' => 'Engine Oil Change',
    'brake' => 'Brake Inspection',
    'wheel' => 'Wheel Alignment',
    'diagnosis' => 'Computer Diagnosis',
    'full' => 'Full Service'
];
function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function showError($errors) {
    http_response_code(400);
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Booking error</title><link rel="stylesheet" href="style.css"></head><body><main class="services-page"><span class="eyebrow">BOOKING NOT SUBMITTED</span><h1>Please check your information.</h1><div class="panel"><ul>';
    foreach ($errors as $error) echo '<li>' . h($error) . '</li>';
    echo '</ul><a class="primary-link" href="index.html#booking">Return to booking form →</a></div></main></body></html>';
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.html');
    exit;
}
$name = trim($_POST['customer_name'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$registration = trim($_POST['registration'] ?? '');
$vehicleType = trim($_POST['vehicle_type'] ?? '');
$model = trim($_POST['vehicle_model'] ?? '');
$year = filter_var($_POST['year'] ?? null, FILTER_VALIDATE_INT);
$date = trim($_POST['service_date'] ?? '');
$services = $_POST['services'] ?? [];
$errors = [];
if ($name === '') $errors[] = 'Customer name is required.';
if (!preg_match('/^\d{10}$/', $phone)) $errors[] = 'Phone number must contain exactly 10 digits.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address.';
if ($registration === '') $errors[] = 'Vehicle registration number is required.';
if (!in_array($vehicleType, ['Saloon Car','SUV','Pickup','Van'], true)) $errors[] = 'Select a valid vehicle type.';
if ($model === '') $errors[] = 'Vehicle model is required.';
$currentYear = (int)date('Y');
if ($year === false || $year < 1950 || $year > $currentYear) $errors[] = 'Enter a reasonable year of manufacture.';
$dateObject = DateTime::createFromFormat('!Y-m-d', $date);
if (!$dateObject || $dateObject->format('Y-m-d') !== $date || $date < date('Y-m-d')) $errors[] = 'Choose a valid date today or in the future.';
if (!is_array($services)) $services = [];
$services = array_values(array_unique($services));
foreach ($services as $service) {
    if (!is_string($service) || !array_key_exists($service, $prices)) {
        $errors[] = 'One or more selected services are invalid.';
        break;
    }
}
if (count($services) === 0) $errors[] = 'Select at least one service.';
if ($errors) showError($errors);

// Individual requirement for CT100/G/23386/24: diagnosis is free when Full Service is selected.
$fullSelected = in_array('full', $services, true);
$total = 0;
foreach ($services as $service) {
    if ($service === 'diagnosis' && $fullSelected) continue;
    $total += $prices[$service];
}
$formattedDate = $dateObject->format('d F Y');
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Service Request Received | AutoCare Garage</title><link rel="stylesheet" href="style.css"></head>
<body>
<header class="site-header"><div class="brand"><span class="brand-mark">A</span><div><strong>AutoCare Garage</strong><small>Reliable vehicle care</small></div></div><nav><a href="index.html">Home</a><a href="service.html">Our Services</a></nav></header>
<main class="services-page">
  <span class="eyebrow">SERVICE REQUEST RECEIVED</span>
  <h1>Thank you, <?= h($name) ?>!</h1>
  <p class="intro">Your service request has been validated and your estimate calculated.</p>
  <section class="panel">
    <h3>Customer and vehicle details</h3>
    <p><strong>Customer:</strong> <?= h($name) ?></p>
    <p><strong>Phone:</strong> <?= h($phone) ?></p>
    <p><strong>Email:</strong> <?= h($email) ?></p>
    <p><strong>Vehicle:</strong> <?= h($registration) ?> · <?= h($model) ?></p>
    <p><strong>Vehicle type:</strong> <?= h($vehicleType) ?></p>
    <p><strong>Year of manufacture:</strong> <?= h($year) ?></p>
    <p><strong>Service date:</strong> <?= h($formattedDate) ?></p>
    <hr>
    <h3>Selected services</h3>
    <?php foreach ($services as $service): ?>
      <div class="estimate-item"><span><?= h($names[$service]) ?><?= ($service === 'diagnosis' && $fullSelected) ? ' (free with Full Service)' : '' ?></span><strong><?= ($service === 'diagnosis' && $fullSelected) ? 'FREE' : 'KSh ' . number_format($prices[$service]) ?></strong></div>
    <?php endforeach; ?>
    <div class="estimate-total"><span>Estimated service cost</span><strong>KSh <?= number_format($total) ?></strong></div>
    <p class="muted">This is an estimate for your selected services, not a payment receipt.</p>
    <a class="primary-link" href="index.html#booking">Make another booking <span>→</span></a>
  </section>
</main>
<footer><strong>AutoCare Garage</strong><span>Vehicle Service Booking & Cost Estimation System · Student Project</span></footer>
</body></html>